package com.example.eBookStoreConfigServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
