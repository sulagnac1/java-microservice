package com.example.ebookstoreapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="Book_Details")
public class Book {
	@Id
	@Column(name="book_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="book_title")
	private String title;
	
	@Column(name="book_publisher")
	private String publisher;
	
	@Column(name="book_isbn")
	private String isbn;
	
	@Column(name="book_number_of_pages")
	private String pages;
	
	@Column(name="book_year")
	private String year;
	
}
